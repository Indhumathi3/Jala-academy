const person = {
  firstName: "rahul",
  lastName: "koppula",
};
// firstWay
console.log(person.firstName);
console.log(person.lastName);

//secondWay
console.log(person["firstName"]);
console.log(person["lastName"]);
